</div>
	<footer class="footer-container">
		<div class="container-fluid">
			<div class="contact-info">
				<div class="quote">
				<p>"The best preparation for tomorrow is doing your best today." - H. Jackson Brown, Jr.</p>
				</div>
				<div class="contacts">
				<p>Email: developer@gmail.com |<br> Phone: +12 345 6783 902 |<br> Tel: 012-345-6789 |</p>
				<a href="https://www.facebook.com/senioritasenioritaph" class="text-decoration-none"><i class="bi bi-facebook"></i></a>
				<a href="#" class="text-decoration-none"><i class="bi bi-twitter"></i></a>
				<a href="#" class="text-decoration-none"><i class="bi bi-github"></i></a>
				</div>
			</div>
		</div>
	</footer>
	<!-- Latest compiled JavaScript -->
	<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
	
</body>
</html>